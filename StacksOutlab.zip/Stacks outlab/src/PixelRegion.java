//Cory Petersens Pixel Region Class
import java.util.ArrayList; //Hooray for automatically growing array capacity
public class PixelRegion {
   int X;
   int Y;
   ArrayList<int[]>checked; //two ArrayList for checked and unchecked pixels, took me forever to figure out I should use two
   ArrayList<int[]>unchecked;
   public PixelRegion(int x, int y){ //constructor with only the location of the pixel inputs
	   X = x;
	   Y = y;
	   checked = new ArrayList<int[]>();  //creates new versions of the list every time the constructor is called
	   unchecked = new ArrayList<int[]>();
	   unchecked.add(new int[]{X-1, Y-1});
	   unchecked.add(new int[]{X+1, Y+1});
	   unchecked.add(new int[]{X-1, Y});
	   unchecked.add(new int[]{X, Y-1});  //again hooray for Arraylist, makes all of these for the program to check every time a 
	   unchecked.add(new int[]{X+1, Y});  //new pixel is looked at and puts them into the unchecked array list for that specific pixel
	   unchecked.add(new int[]{X, Y+1});
	   unchecked.add(new int[]{X-1, Y+1});
	   unchecked.add(new int[]{X+1, Y-1});
   }
   
   public int[] getNextUnchecked(){
	   int[] pix = unchecked.get(0);
	   checked.add(unchecked.remove(0));  //for use in the fun2 method, checks an unchecked pixel and sets it to checked
	   return pix;
  }
   
   public int getX(){ //a couple getters for the X and Y values of a specific pixel
	   return X;
   }
   public int getY(){
	   return Y;
   }
   public boolean allDone(){
	   if(unchecked.isEmpty()){ //the ending statement for the program, if there are no unchecked surrounding pixels, the pixel is popped
		   return true;}
	   else{return false;} //else return false
   }
}
